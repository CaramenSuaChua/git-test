import React from "react";

function Home () {
    return(
        <div className="container">
            <h4> Home </h4>
        </div>
    )
}

export default Home;